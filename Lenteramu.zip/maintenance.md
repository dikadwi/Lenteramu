CBF : Prioritas dari hasil RL

Label kan tiap data produk/ misi dll untuk mengkategorikan ke CBF
Tingkat kesulitan (easy/medium/hard).
